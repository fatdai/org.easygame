

var Constants = {};

// login
Constants.OP_LOGIN = 100;
Constants.OP_LOGIN_REPLY = 100;
Constants.OP_REGIST = 100;
Constants.OP_REGIST_REPLY = 100;


// json key
Constants.JK_OP = "op";
Constants.JK_USERNAME = "username";
Constants.JK_PASSWORD = "password";